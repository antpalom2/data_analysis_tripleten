
# 🚖 Zuber SQL Analysis

This project explores taxi ride data from the fictional company **Zuber**, focusing on ride patterns, weather conditions, and passenger behavior in Chicago.

The goal is to use SQL to uncover key insights into company performance, passenger preferences, and the external factors—such as weather—that impact ride frequency and duration.

---

## 📚 Skills & Techniques Applied

This project was completed as part of the **SQL & Relational Databases** sprint in TripleTen's Business Intelligence Analyst program.

### 🧮 SQL Concepts Covered
- Filtering, grouping, and joining multiple relational tables  
- Use of `CASE`, `HAVING`, and `CAST` operators  
- Conditional logic using `CASE` to classify weather  
- Extracting date parts (`ISODOW`) to filter by weekday  
- Aggregation with `COUNT()` and time-based filtering

### 🔎 Data Sources
- `trips` – taxi rides  
- `cabs` – vehicle and company information  
- `weather_records` – hourly temperature and conditions  
- `neighborhoods` – geographic identifiers

---

## 🔍 Objective

To investigate:

- Which taxi companies had the highest ride counts in specific timeframes  
- The impact of weather on trip duration from the Loop to O’Hare on Saturdays  
- Overall ride activity segmented by company or weather condition

---

## 📊 SQL Queries & Insights

### 1. Top Taxi Companies by Ride Volume (Nov 15–16, 2017)
```sql
SELECT
    cabs.company_name AS company_name,
    COUNT(trips.trip_id) AS trips_amount
FROM
    cabs
LEFT JOIN trips ON cabs.cab_id = trips.cab_id
WHERE
    CAST(start_ts AS DATE) BETWEEN '2017-11-15' AND '2017-11-16'
GROUP BY
    cabs.company_name
ORDER BY
    trips_amount DESC;
```
**Insight:**  
Flash Cab had the highest volume over this period, suggesting strong coverage or demand.

---

### 2. Rides by “Yellow” and “Blue” Companies (Nov 1–7, 2017)
```sql
SELECT
    cabs.company_name AS company_name,
    COUNT(trips.trip_id) AS trips_amount
FROM
    cabs
LEFT JOIN trips ON cabs.cab_id = trips.cab_id
WHERE
    CAST(start_ts AS DATE) BETWEEN '2017-11-01' AND '2017-11-07'
GROUP BY
    cabs.company_name
HAVING
    cabs.company_name LIKE '%Yellow%' OR cabs.company_name LIKE '%Blue%'
ORDER BY
    trips_amount DESC;
```
**Insight:**  
Yellow Cab and its affiliates led in trip counts, indicating brand dominance or fleet size advantages.

---

### 3. Grouping Popular vs. Other Taxi Companies
```sql
SELECT
    COUNT(trips.trip_id) AS trips_amount,
    CASE
        WHEN cabs.company_name IN ('Flash Cab', 'Taxi Affiliation Services') THEN cabs.company_name
        ELSE 'Other'
    END AS company
FROM
    cabs
LEFT JOIN trips ON cabs.cab_id = trips.cab_id
WHERE
    CAST(start_ts AS DATE) BETWEEN '2017-11-01' AND '2017-11-07'
GROUP BY
    company
ORDER BY
    trips_amount DESC;
```
**Insight:**  
The majority of rides were by companies outside the top two, suggesting a fragmented market.

---

### 4. Identifying Neighborhood IDs for Loop and O’Hare
```sql
SELECT *
FROM neighborhoods
WHERE name = 'Loop' OR name LIKE '%Hare%';
```
**Insight:**  
Loop has ID 50, and O’Hare has ID 63 — used for later analysis.

---

### 5. Classify Weather as Good or Bad
```sql
SELECT
    ts,
    CASE
        WHEN description LIKE '%rain%' THEN 'Bad'
        WHEN description LIKE '%storm%' THEN 'Bad'
        ELSE 'Good'
    END AS weather_conditions
FROM
    weather_records;
```
**Insight:**  
Allows joining ride start times to weather conditions, enabling contextual analysis.

---

### 6. Duration of Rides on Rainy Saturdays from Loop to O’Hare
```sql
SELECT
    trips.start_ts,
    CASE
        WHEN weather_records.description LIKE '%rain%' THEN 'Bad'
        WHEN weather_records.description LIKE '%storm%' THEN 'Bad'
        ELSE 'Good'
    END AS weather_conditions,
    trips.duration_seconds
FROM
    trips
INNER JOIN weather_records ON weather_records.ts = trips.start_ts
WHERE
    pickup_location_id = 50
    AND dropoff_location_id = 63
    AND EXTRACT(ISODOW FROM weather_records.ts) = 6
ORDER BY
    trips.trip_id;
```
**Insight:**  
Rides on rainy Saturdays showed higher average durations, suggesting weather delays.

---

## 🛠 Tools Used

- PostgreSQL (Query Execution & Analysis)  
- TripleTen Platform (Project Environment)  
- GitHub (Version Control & Documentation)

---

🚀 *Final project submission for the SQL & Relational Databases sprint at TripleTen.*
